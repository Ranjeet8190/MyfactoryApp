import React from 'react';

function Dashboard() {
  return (
    <div>
      <h2>Dashboard (Dummy)</h2>
      <p>Welcome to Maahee's MyFactoryApp Dashboard</p>
    </div>
  );
}

export default Dashboard;

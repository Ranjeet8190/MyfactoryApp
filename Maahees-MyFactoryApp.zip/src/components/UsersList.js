import React from 'react';

function UsersList() {
  return (
    <div>
      <h2>Users List (Dummy)</h2>
      <ul>
        <li>Dummy User 1</li>
        <li>Dummy User 2</li>
        <li>Dummy User 3</li>
      </ul>
    </div>
  );
}

export default UsersList;

import React from 'react';

function Login() {
  return (
    <div>
      <h2>Login (Dummy)</h2>
      <input type="text" placeholder="Email" />
      <input type="password" placeholder="Password" />
      <button>Login</button>
    </div>
  );
}

export default Login;
